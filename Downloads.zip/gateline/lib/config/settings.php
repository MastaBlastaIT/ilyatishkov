<?php

return array(
    'GL_SITE_UID' => array(
        'value'        => '',
        'title'        => 'Site UID',
        'description'  => 'Ваш UID сайта',
        'control_type' => 'input',
    ),
    'GL_SITE_PASSWORD' => array(
        'value'        => '',
        'title'        => 'Пароль сайта',
        'description'  => '16-ричный пароль Вашего сайта для запросов к API',
        'control_type' => 'input',
    ),
    'APIMODE' => array(
        'value'        => '',
        'title'        => 'Интеграция по API',
        'description'  => 'По умолчанию - SimpleAPI',
        'control_type' => 'checkbox',
    ),
    'CERT' => array(
        'value'        => '',
        'title'        => 'Файл сертификата',
        'description'  => 'Загрузите Ваш клиентский сертификат (.crt, .pem)',
        'control_type' => waHtmlControl::FILE,
    ),
    'KEY' => array(
        'value'        => '',
        'title'        => 'Файл ключа',
        'description'  => 'Загрузите Ваш ключ (.key, .pem)',
        'control_type' => waHtmlControl::FILE,
    ),
    'PASSPHRASE' => array(
        'value' => '',
        'title' => 'Парольная фраза (могла быть не задана)',
        'description'      => <<<HTML
Парольная фраза, которую (если) Вы задали при разбиении файла .p12<br>
Оставить поле пустым, если фраза не была задана
<br><br>
<strong style="color: red">ПРЕДВАРИТЕЛЬНО НУЖНО РАЗБИТЬ ПОЛУЧЕННЫЙ ВАМИ .P12 ФАЙЛ НА ФАЙЛЫ СЕРТИФИКАТА И КЛЮЧА</strong>
<script type="text/javascript">
    (function () {
        var toggle = function (input, event, selector, show) {
            if (show === undefined) {
                show = input.checked;
            }
            $(input).parents('form').find(selector).each(function () {
                if (show) {
                    $(this).parents('div.field').show('300');
                } else {
                    $(this).parents('div.field').hide(event.originalEvent ? '300' : 0);
                }
            });
        };
        $(':input[name$="\[APIMODE\]"]').unbind('change').bind('change', function (event) {
            toggle(this, event, ':input[name$="\[CERT\]"]');
            toggle(this, event, ':input[name$="\[KEY\]"]');
            toggle(this, event, ':input[name$="\[PASSPHRASE\]"]');
        }).trigger('change');
    })();
</script>
HTML
,
        'control_type'     => 'input',
    ),
);
