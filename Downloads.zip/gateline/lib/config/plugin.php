<?php
return array(
    'name'        => 'Gateline',
    'description' => 'Оплата услуг через платежный шлюз <a href="http://gateline.net/">Gateline</a>',
    'icon'        => 'img/gl31.png',
    'logo'        => 'img/gl3.png',
    'vendor'      => '1114821',
    'version'     => '0.0.2',
    'type'        => waPayment::TYPE_ONLINE,
);
