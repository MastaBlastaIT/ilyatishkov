<?php
return array(
    array(
        'value'       => 'https://simpleapi.sandbox.gateline.net:18610/pay',
        'title'       => 'POST simpleapi/pay',
        'description' => '<span>URL(https), на который отправляется запрос [Интеграция по SimpleAPI]</span>',
    ),
    array(
        'value'       => 'https://api.sandbox.gateline.net:18210/checkout/pay',
        'title'       => 'POST checkout/pay',
        'description' => '<span>URL(https), на который отправляется запрос [Интеграция по API]</span>',
    ),
    array(
        'value'       => 'https://api.sandbox.gateline.net:18210/order/authorize',
        'title'       => 'POST order/authorize',
        'description' => '<span>URL(https), на который отправляется запрос [Интеграция по API]</span>',
    ),
    array(
        'value'       => 'https://api.sandbox.gateline.net:18210/order/authorize3d',
        'title'       => 'POST order/authorize3d',
        'description' => '<span>URL(https), на который отправляется запрос [Интеграция по API]</span>',
    ),
);
