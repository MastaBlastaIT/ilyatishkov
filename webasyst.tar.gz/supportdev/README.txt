Доступ в интерфейс партнера

 https://partner.sandbox.gateline.net:18410/

 Логин: supportdev
 Пароль: vY+I/KDm2fgV
 Пароль на сертификат: a6193vu/hBxu

Документация по подключению и тестированию

 https://partner.sandbox.gateline.net:18410/partner/journal/docs

Доступ к API

 https://api.sandbox.gateline.net:18210/

 Упрощенный доступ для первоначального тестирования (без проверки подписи запроса):
 https://api.sandbox.gateline.net:18220/

 SimpleAPI:
 https://simpleapi.sandbox.gateline.net:18610/

 Идентификатор сайта: supportdevru
 Пароль сайта: 4c99ddd05c292f2bd7ef026e5ca763b9
 Пароль на сертификат: UYuzcjIOxA8P
